<?php 

$lang["migrate_backup"] = "Se recomienda realizar una copia de seguridad de la base de datos antes de aplicar cualquier actualización.";
$lang["migrate_failed"] = "La migración no se completó.";
$lang["migrate_info"] = "Presiona en Iniciar Migración solo si estás preparado para aplicar todos los cambios en la base de datos y la actualización de los datos";
$lang["migrate_start"] = "Iniciar Migración ";
$lang["migrate_success"] = "Migración completada correctamente";
