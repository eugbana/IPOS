<?php 

$lang["tables_all"] = "Tudo";
$lang["tables_columns"] = "Colunas";
$lang["tables_hide_show_pagination"] = "Ocultar/Exibir paginação";
$lang["tables_loading"] = "Carregando, aguarde...";
$lang["tables_page_from_to"] = "Exibindo {0} até {1} de {2} linhas";
$lang["tables_refresh"] = "Recarregar";
$lang["tables_rows_per_page"] = "{0}  registros por página";
$lang["tables_toggle"] = "Ocultar/Exibir paginação";
