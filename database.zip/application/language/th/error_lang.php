<?php 

$lang["error_no_permission_module"] = "คุณไม่ได้รับสิทธิ์การเข้าถึงข้อมูลในส่วนนี้";
$lang["error_unknown"] = "ไม่ทราบ";
