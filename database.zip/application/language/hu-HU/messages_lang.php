<?php 

$lang["messages_first_name"] = "Keresztnév";
$lang["messages_last_name"] = "Vezetéknév";
$lang["messages_message"] = "Üzenet";
$lang["messages_message_placeholder"] = "Az Ön üzente...";
$lang["messages_message_required"] = "Üzenet kötelező";
$lang["messages_multiple_phones"] = "(Több címzett esetében a telefonszámokat vesszővel válassza el)";
$lang["messages_phone"] = "Telefonszám";
$lang["messages_phone_number_required"] = "Telefonszám kötelező";
$lang["messages_phone_placeholder"] = "Mobil telefonszám(ok) ide...";
$lang["messages_sms_send"] = "SMS küldés";
$lang["messages_successfully_sent"] = "Az üzenet sikeresen elküldve: ";
$lang["messages_unsuccessfully_sent"] = "Sikertelen üzenet küldés:: ";
