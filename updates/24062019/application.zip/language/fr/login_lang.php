<?php 

$lang["login_go"] = "Lancer";
$lang["login_invalid_username_and_password"] = "Entrée invalide";
$lang["login_login"] = "Login";
$lang["login_password"] = "Mot de passe";
$lang["login_username"] = "Nom d'utilisateur";
