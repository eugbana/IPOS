<?php 

$lang["error_no_permission_module"] = "ليس لديك صلاحيات للوصول لهذا القسم";
$lang["error_unknown"] = "غير معروف";
