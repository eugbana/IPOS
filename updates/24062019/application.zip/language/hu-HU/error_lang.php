<?php 

$lang["error_no_permission_module"] = "Önnek nincs hozzáférése az alábbi modulhoz ";
$lang["error_unknown"] = "ismeretlen";
