<?php 

$lang["suppliers_account_number"] = "Hesap No";
$lang["suppliers_agency_name"] = " ";
$lang["suppliers_cannot_be_deleted"] = "Sağlayıcı silinemedi, bazı sağlayıcıların satışı var.";
$lang["suppliers_company_name"] = "Şirket Adı";
$lang["suppliers_company_name_required"] = "Şirket Adı zorunlu alandır";
$lang["suppliers_confirm_delete"] = "Seçili sağlayıcıları düzenlemek istiyor musunuz?";
$lang["suppliers_error_adding_updating"] = "Sağlayıcı ekleme/düzenleme hatası";
$lang["suppliers_new"] = "Yeni Sağlayıcı";
$lang["suppliers_none_selected"] = "Silmek için sağlayıcı seçmediniz";
$lang["suppliers_one_or_multiple"] = "sağlayıcılar";
$lang["suppliers_successful_adding"] = "Sağlayıcı eklendi";
$lang["suppliers_successful_deleted"] = "Sağlayıcı silindi";
$lang["suppliers_successful_updating"] = "Sağlayıcı düzenlendi";
$lang["suppliers_supplier"] = "Sağlayıcı";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_update"] = "Sağlayıcıyı Düzenle";
