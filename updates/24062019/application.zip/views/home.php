<?php $this->load->view("partial/header"); ?>

<script type="text/javascript">
	dialog_support.init("a.modal-dlg");
</script>
<div class="content-page">
                <!-- Start content -->
                <div class="content">

<h3 class="text-center"><?php echo 'Welcome! Click on any module to continue'; ?></h3>

<div id="home_module_list">
	
</div>
</div>
</div>


<?php $this->load->view("partial/footer"); ?>