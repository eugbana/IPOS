<?php 

$lang["login_go"] = "Ir";
$lang["login_invalid_username_and_password"] = "Usuario/Contraseña inválidos";
$lang["login_login"] = "Iniciar Sesión";
$lang["login_password"] = "Contraseña";
$lang["login_username"] = "Usuario";
