<?php 

$lang["messages_first_name"] = "First name";
$lang["messages_last_name"] = "Last name";
$lang["messages_message"] = "Message";
$lang["messages_message_placeholder"] = "Your Message here...";
$lang["messages_message_required"] = "Message required";
$lang["messages_multiple_phones"] = "(In case of multiple recipients, enter mobile numbers separated by commas)";
$lang["messages_phone"] = "Phone number";
$lang["messages_phone_number_required"] = "Phone number required";
$lang["messages_phone_placeholder"] = "Mobile Number(s) here...";
$lang["messages_sms_send"] = "Send SMS";
$lang["messages_successfully_sent"] = "Message successfully sent to: ";
$lang["messages_unsuccessfully_sent"] = "Message unsuccessfully sent to: ";
