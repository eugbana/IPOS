<?php 

$lang["login_go"] = "";
$lang["login_invalid_username_and_password"] = "";
$lang["login_login"] = "";
$lang["login_password"] = "";
$lang["login_username"] = "";
